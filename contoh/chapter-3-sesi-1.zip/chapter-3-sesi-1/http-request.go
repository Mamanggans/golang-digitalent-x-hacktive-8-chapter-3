package main

import (
	"bytes"
	"fmt"
	"io"
	"io/ioutil"
	"log"
	"mime/multipart"
	"net/http"
	"os"
)

type Todo struct {
	UserId    int    `json:"userId"`
	Id        int    `json:"id"`
	Title     string `json:"title"`
	Completed bool   `json:"completed"`
}

type TodoRequest struct {
	UserId    int    `json:"userId"`
	Title     string `json:"title"`
	Completed bool   `json:"completed"`
}

func main() {
	// apiUrl := "https://jsonplaceholder.typicode.com/todos"

	// todoRequest := TodoRequest{
	// 	UserId:    3,
	// 	Title:     "Suatu Data Todo Baru",
	// 	Completed: false,
	// }

	// bs, err := json.Marshal(todoRequest)

	// if err != nil {
	// 	log.Panicf("error while converting struct to json => %s \n", err.Error())
	// }

	// request, err := http.NewRequest(http.MethodPost, apiUrl, bytes.NewBuffer(bs))

	// if err != nil {
	// 	log.Panicf("error while defining the request => %s \n", err.Error())
	// }

	// request.Header.Set("Content-Type", "application/json")

	// client := &http.Client{}

	// response, err := client.Do(request)

	// if err != nil {
	// 	log.Panicf("error while sending the request => %s \n", err.Error())
	// }

	// defer response.Body.Close()

	// responseBody, err := ioutil.ReadAll(response.Body)

	// if err != nil {
	// 	log.Panicf("error while reading the response body => %s \n", err.Error())
	// }

	// fmt.Println(string(responseBody))

	// handleGetRequest()

	// handleFormDataPostMethod()

	handleImageFormData()
}

func handleImageFormData() {
	apiUrl := "http://localhost:8080/images"

	file, err := os.Open("image.webp")

	if err != nil {
		log.Panicf("error while opening the image file => %s \n", err.Error())
	}

	defer file.Close()

	body := &bytes.Buffer{}

	writer := multipart.NewWriter(body)

	part, err := writer.CreateFormFile("image-file", file.Name())

	if err != nil {
		log.Panicf("error while creating the form file instance => %s \n", err.Error())
	}

	_, err = io.Copy(part, file)

	if err != nil {
		log.Panicf("error while copying file data to the buffer instance => %s \n", err.Error())
	}

	writer.Close()

	request, err := http.NewRequest(http.MethodPost, apiUrl, body)

	if err != nil {
		log.Panicf("error while defining request %s \n", err.Error())
	}

	request.Header.Set("Content-Type", writer.FormDataContentType())

	client := &http.Client{}

	response, err := client.Do(request)

	if err != nil {
		log.Panicf("error while sending the api request %s \n", err.Error())
	}

	defer response.Body.Close()

	responseBody, err := ioutil.ReadAll(response.Body)

	if err != nil {
		log.Panicf("error while reading the response body %s \n", err.Error())
	}

	fmt.Println(string(responseBody))
}

func handleFormDataPostMethod() {
	apiUrl := "http://localhost:8080/products"

	body := &bytes.Buffer{}

	writer := multipart.NewWriter(body)

	writer.WriteField("title", "Jaket Coklat")

	writer.Close()

	request, err := http.NewRequest(http.MethodPost, apiUrl, body)

	if err != nil {
		log.Panicf("error while defining request %s \n", err.Error())
	}

	request.Header.Set("Content-Type", writer.FormDataContentType())

	// request.Body = ioutil.NopCloser(body)

	client := &http.Client{}

	response, err := client.Do(request)

	if err != nil {
		log.Panicf("error while sending the request => %s \n", err.Error())
	}

	defer response.Body.Close()

	responseBody, err := ioutil.ReadAll(response.Body)

	if err != nil {
		log.Panicf("error while reading the response body => %s \n", err.Error())
	}

	fmt.Println(string(responseBody))

}

func handleGetRequest() {
	apiUrl := "http://localhost:8080/products"

	request, err := http.NewRequest(http.MethodGet, apiUrl, nil)

	if err != nil {
		log.Panicf("error while defining request %s \n", err.Error())
	}

	client := &http.Client{}

	response, err := client.Do(request)

	if err != nil {
		log.Panicf("error while sending the request %s \n", err.Error())
	}

	defer response.Body.Close()

	responseBody, err := ioutil.ReadAll(response.Body)

	if err != nil {
		log.Panicf("error while reading response body %s \n", err.Error())
	}

	fmt.Println(string(responseBody))

	// todos := []Todo{}

	// err = json.Unmarshal(responseBody, &todos)

	// fmt.Printf("%#v \n", todos)
}
