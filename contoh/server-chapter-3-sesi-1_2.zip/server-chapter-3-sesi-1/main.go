package main

// import (
// 	"encoding/json"
// 	"fmt"
// 	"io/ioutil"
// 	"net/http"
// 	"os"
// )

// type Product struct {
// 	Id    int    `json:"id"`
// 	Title string `json:"title"`
// }

// var products = []Product{
// 	{
// 		Id:    1,
// 		Title: "Kemeja Hijau",
// 	},
// 	{
// 		Id:    2,
// 		Title: "Kemeja Merah",
// 	},
// 	{
// 		Id:    3,
// 		Title: "Kemeja Biru",
// 	},
// }

// func main() {
// 	http.HandleFunc("/products", mainEndpoint)

// 	http.HandleFunc("/images", handleImageCreation)

// 	fmt.Println("Server running on PORT:", "8080")
// 	http.ListenAndServe(":8080", nil)
// }

// func handleImageCreation(w http.ResponseWriter, r *http.Request) {
// 	imageFile, imageHeader, err := r.FormFile("image-file")

// 	if err != nil {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		w.Write([]byte(err.Error()))
// 		return
// 	}

// 	newFile, err := os.Create(imageHeader.Filename)

// 	if err != nil {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		w.Write([]byte(err.Error()))
// 		return
// 	}

// 	bs, err := ioutil.ReadAll(imageFile)

// 	if err != nil {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		w.Write([]byte(err.Error()))
// 		return
// 	}

// 	_, err = newFile.Write(bs)

// 	w.Write([]byte(imageHeader.Filename))
// }

// func mainEndpoint(w http.ResponseWriter, r *http.Request) {
// 	if r.Method == http.MethodPost {
// 		createProduct(w, r)
// 		return
// 	}

// 	if r.Method == http.MethodGet {
// 		getProducts(w, r)
// 		return
// 	}
// }

// func createProduct(w http.ResponseWriter, r *http.Request) {
// 	title := r.FormValue("title")

// 	fmt.Println(r.MultipartForm)

// 	newProduct := Product{
// 		Id:    products[len(products)-1].Id + 1,
// 		Title: title,
// 	}

// 	products = append(products, newProduct)

// 	w.WriteHeader(http.StatusCreated)
// 	w.Write([]byte("new product created"))
// }

// func getProducts(w http.ResponseWriter, r *http.Request) {
// 	bs, err := json.Marshal(products)

// 	fmt.Println("Request Masuk!!!")

// 	if err != nil {
// 		w.WriteHeader(http.StatusInternalServerError)
// 		w.Write([]byte("something went wrong"))
// 		return
// 	}

// 	w.Header().Set("Content-Type", "application/json")
// 	w.Write(bs)
// }
